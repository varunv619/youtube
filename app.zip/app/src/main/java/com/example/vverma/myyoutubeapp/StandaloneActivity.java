package com.example.vverma.myyoutubeapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.google.android.youtube.player.YouTubeIntents;
import com.google.android.youtube.player.YouTubeStandalonePlayer;

/**
 * Created by JMDJMD on 12/13/2016.
 */

public class StandaloneActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_standalone);

        Button btnvideo = (Button) findViewById(R.id.videobtn);
        Button btnlist = (Button) findViewById(R.id.listbtn);

        btnvideo.setOnClickListener(this);
        btnlist.setOnClickListener(this);
//        View.OnClickListener onClickListener = new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        };
//
//        btnvideo.setOnClickListener(onClickListener);
//        btnlist.setOnClickListener(onClickListener);
    }
    @Override
    public void onClick(View view) {

        Intent intent = null;

        switch(view.getId()){

            case R.id.videobtn:
                intent = YouTubeStandalonePlayer.createVideoIntent(this, YoutubeActivity.GOOGLE_API_KEY, YoutubeActivity.YOUTUBE_VIDEO,10,true,true);
            case R.id.listbtn:
                intent = YouTubeStandalonePlayer.createPlaylistIntent(this, YoutubeActivity.GOOGLE_API_KEY, YoutubeActivity.YOUTUBE_ID);

            default:
        }

        if(intent!=null){
            startActivity(intent);
        }

    }
}
