package com.example.vverma.myyoutubeapp;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Button btnSingle = (Button) findViewById(R.id.btnplayvid);
        Button btnStandalone = (Button) findViewById(R.id.btnplaylist);

        btnSingle.setOnClickListener(this);
        btnStandalone.setOnClickListener(this);

        ImageView imageView = (ImageView) findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.youtubepng);

    }

    @Override
    public void onClick(View view) {

        Intent intent = null;

        switch(view.getId()){

            case R.id.btnplayvid:
                intent = new Intent(this, YoutubeActivity.class);
            case R.id.btnplaylist:
                intent = new Intent(this,StandaloneActivity.class);
            default:
        }
if(intent!=null) {
    startActivity(intent);
}
    }
}
